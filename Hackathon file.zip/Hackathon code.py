import tkinter as tk
from tkinter import messagebox, filedialog
from PIL import Image, ImageTk, ImageDraw
import random

# Gujarati Alphabets and image paths (Add your own images here)
gujarati_alphabets = {
    "અ": "images/a_sign.png",
    "આ": "images/aa_sign.png",
    "ઇ": "images/i_sign.png",
    "ઈ": "images/ii_sign.png",
   
}

class LearningApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gujarati Learning App for Deaf and Mute")
        self.root.geometry("800x600")

        self.main_menu()

    def main_menu(self):
        self.clear()
        tk.Label(self.root, text="Welcome to Learning App", font=("Helvetica", 20, "bold")).pack(pady=20)
        tk.Button(self.root, text="📖 Learn Gujarati Alphabets", width=30, command=self.learn_alphabets).pack(pady=10)
        tk.Button(self.root, text="✍️ Practice Writing", width=30, command=self.writing_pad).pack(pady=10)
        tk.Button(self.root, text="🧮 Math Quiz", width=30, command=self.math_quiz).pack(pady=10)

    def learn_alphabets(self):
        self.clear()
        tk.Label(self.root, text="Gujarati Alphabets", font=("Helvetica", 18)).pack(pady=10)
        frame = tk.Frame(self.root)
        frame.pack()

        for letter, img_path in gujarati_alphabets.items():
            try:
                img = Image.open(img_path).resize((100, 100))
                photo = ImageTk.PhotoImage(img)
                label = tk.Label(frame, image=photo)
                label.image = photo
                label.pack(side=tk.LEFT, padx=10)
                tk.Label(frame, text=letter, font=("Helvetica", 16)).pack(side=tk.LEFT, padx=10)
            except:
                tk.Label(frame, text=f"{letter} (Image missing)", fg="red").pack(side=tk.LEFT)

        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=20)

    def writing_pad(self):
        self.clear()
        tk.Label(self.root, text="Practice Writing", font=("Helvetica", 18)).pack(pady=10)

        canvas = tk.Canvas(self.root, width=600, height=400, bg='white')
        canvas.pack()

        self.old_x = None
        self.old_y = None
        self.draw = ImageDraw.Draw(Image.new("RGB", (600, 400), "white"))

        def start_draw(event):
            self.old_x = event.x
            self.old_y = event.y

        def draw_line(event):
            if self.old_x and self.old_y:
                canvas.create_line(self.old_x, self.old_y, event.x, event.y, width=3)
                self.old_x = event.x
                self.old_y = event.y

        def reset(event):
            self.old_x, self.old_y = None, None

        def clear_canvas():
            canvas.delete("all")

        canvas.bind("<Button-1>", start_draw)
        canvas.bind("<B1-Motion>", draw_line)
        canvas.bind("<ButtonRelease-1>", reset)

        tk.Button(self.root, text="Clear", command=clear_canvas).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.main_menu).pack()

    def math_quiz(self):
        self.clear()
        tk.Label(self.root, text="Math Quiz - Multiplication", font=("Helvetica", 18)).pack(pady=10)

        num1 = random.randint(1, 10)
        num2 = random.randint(1, 10)
        correct = num1 * num2

        question = f"{num1} × {num2} = ?"
        tk.Label(self.root, text=question, font=("Helvetica", 16)).pack(pady=10)
        answer_entry = tk.Entry(self.root)
        answer_entry.pack()

        def check_answer():
            try:
                ans = int(answer_entry.get())
                if ans == correct:
                    messagebox.showinfo("Correct!", "Well done! ✅")
                else:
                    messagebox.showerror("Oops!", f"Wrong. The correct answer is {correct}")
                self.math_quiz()
            except:
                messagebox.showwarning("Invalid", "Please enter a number")

        tk.Button(self.root, text="Submit", command=check_answer).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.main_menu).pack(pady=10)

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()


# Run the app
root = tk.Tk()
app = LearningApp(root)
root.mainloop()
